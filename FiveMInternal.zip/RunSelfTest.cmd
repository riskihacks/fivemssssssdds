@echo off
cd /d "%~dp0"
start "" "%~dp0DX11TestHost.exe"
timeout /t 2 /nobreak >nul
"%~dp0FiveMInternalLoader.exe" --test-host
