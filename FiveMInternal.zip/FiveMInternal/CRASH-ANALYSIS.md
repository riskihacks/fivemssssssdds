# Analisis crash FiveMInternal 2.2 dan perubahan 2.3

Analisis memakai log DLL dan dump yang dikirim pengguna, bukan eksekusi FiveM
di cloud. Tidak ada data akun, alamat server, atau isi dump dalam paket ini.

## Bukti dari pengujian pengguna

- Metadata DLL dalam dump cocok dengan payload yang dipublikasikan di commit
  `6187cdf38d375dfae6495ebd0fe2aa99695867c4`: timestamp `0x6AD1FF87`,
  SizeOfImage `0x25B000`.
- Exception `0xC0000005`, jenis execute fault, pada thread `MainThrd` di
  `FiveM_b3751_GTAProcess.exe+0x101C`.
- Source resmi FiveM mengklasifikasikan execute fault dalam rentang
  image base + `0x1000` sampai sebelum `0x2000` sebagai jalur Early-exit trap.
  Klasifikasi ini tidak mengungkap pemeriksaan/operasi yang memicunya.
- Log 17:50:56–17:51:46 WIB menunjukkan satu replay pool tervalidasi. Mulai
  17:51:06, `otherPlayers=1`; `readErrors=0`. Jadi penemuan pemain lain berjalan.
- Heartbeat terakhir memiliki `frameAgeMs=4844`, sementara pembacaan entity masih
  berjalan. Log lama tidak mencatat tahap render sehingga tidak dapat membedakan
  macet di overlay, original Present, atau pekerjaan game setelah Present kembali.
- Rekonstruksi parsial memakai metadata unwind memberikan urutan kandidat
  GTAProcess +101C, +25A0E1, +258FBC, +25A333, +28C766, +274EFE, lalu
  gta-core-five.dll +8902F. Metadata lanjutan dan sebagian kode epilog tidak
  tersedia; ini bukan call stack lengkap dengan simbol. Tidak ada dasar untuk
  menyimpulkan bahwa stack tersebut membuktikan masalah driver atau suatu bypass.

## Cacat renderer yang diperbaiki

Backend ImGui 1.91.9b mengosongkan hull/domain/compute shader (HS/DS/CS) dan tidak
memulihkannya. Scope versi 2.2 hanya menambah pemulihan target output/UAV, sehingga
state shader game masih bisa berubah. Pengikatan render target juga dapat
mengosongkan shader-resource views yang bertabrakan dengan target itu.

Versi 2.3 menggunakan private D3D11.1 device context state selama frame overlay.
State game dipulihkan saat frame selesai maupun saat terjadi exception C++.
Binding private dibersihkan sebelum kembali ke game agar buffer tidak tertahan
oleh context state yang sedang tidak aktif ketika ResizeBuffers dipanggil.

Log baru mencatat tahap render, umur tahap, thread, jumlah panggilan/kembalinya
original Present, HRESULT dan hasil resize. Pemain lain tetap dibaca/digambar
melalui pool yang sama. Perubahan ini tidak mengaktifkan nama asli atau noclip.

## Status verifikasi

Cacat state renderer dapat dibuktikan dari source dan perilaku API yang
didokumentasikan. Perbaikannya belum diuji pada FiveM/Windows oleh agen.
Hubungan cacat tersebut dengan Early-exit trap pengguna belum terbukti;
versi 2.3 bukan jaminan bebas crash atau kompatibel semua server/build.

`RunRendererChecks.cmd` menjalankan regresi DirectX WARP pada Windows tanpa FiveM.
Pengujian itu memeriksa state shader/resource, 200 frame, pemulihan setelah
exception, pelepasan binding RTV dan hasil compute shader setelah pemulihan.
Hasil build/check portabel dicatat terpisah dalam VALIDATION.txt.

## Rujukan

- [Klasifikasi crash FiveM](https://github.com/citizenfx/fivem/blob/master/code/client/launcher/MiniDump.cpp)
- [Backend ImGui 1.91.9b](https://github.com/ocornut/imgui/blob/v1.91.9b/backends/imgui_impl_dx11.cpp)
- [SwapDeviceContextState](https://learn.microsoft.com/en-us/windows/win32/api/d3d11_1/nf-d3d11_1-id3d11devicecontext1-swapdevicecontextstate)
- [CreateDeviceContextState](https://learn.microsoft.com/en-us/windows/win32/api/d3d11_1/nf-d3d11_1-id3d11device1-createdevicecontextstate)
