FiveM Internal 2.3 — EKSPERIMENTAL

PERUBAHAN 2.3
- Memperbaiki state renderer: overlay memakai private D3D11.1 context state,
  lalu memulihkan state game utuh, termasuk shader HS/DS/CS dan resource bindings.
- State dipulihkan juga saat exception C++; binding private dibersihkan agar
  back buffer tidak tertahan ketika resize. Present rekursif tidak menggambar ulang.
- Log menambahkan tahap render, thread, umur tahap, jumlah original Present
  masuk/kembali, HRESULT, serta hasil ResizeBuffers.
- ESP pemain lain tetap tersedia. Semua fitur tetap mulai OFF.
- RunRendererChecks.cmd tersedia dalam ZIP untuk pengujian state DirectX WARP
  tanpa FiveM; belum dijalankan pada Windows oleh agen.

CARA MENCOBA
1. Tutup FiveM sepenuhnya. Unduh EXE baru dan jalankan sesi FiveM kembali.
2. Buka FiveMInternalLoader.exe, klik Inject lalu kembali ke FiveM.
3. Tekan C. Aktifkan Enable ESP serta Skeleton/Box. Semua opsi awalnya OFF.
4. Show local player hanya untuk diri sendiri; biarkan OFF saat menguji pemain
   lain. Show NPC untuk NPC. Slider 10–1000 m memfilter entity yang sudah di-stream.
5. F6 master ESP ON/OFF, F7 scan ulang. Tab/Space untuk navigasi keyboard.
6. Uji dekat pemain lain. Debug Other players harus >0 untuk memastikan pool
   berisi kandidat pemain lain. Projected entities menunjukkan hasil proyeksi.

STATUS DAN BATAS
Dump versi 2.2 menunjukkan execute fault pada GTAProcess+0x101C di MainThrd.
Log membuktikan satu pemain lain terdeteksi dan pembacaan tidak gagal, tetapi
frame berhenti menjelang Early-exit trap. Pemicu trap belum diketahui pasti.
Versi 2.3 memperbaiki cacat state DirectX yang ditemukan dari audit source;
hubungannya dengan trap belum terbukti. Belum diuji pada Windows/FiveM di cloud.
Jangan menganggap kelulusan build/check portabel sebagai jaminan tidak crash.
Rincian analisis tersedia dalam CRASH-ANALYSIS.md.

Pencarian pool otomatis tidak menjamin kecocokan semua build/server. Jika replay
atau layout player-info tidak valid, debug menjelaskan kegagalan. Profil eksplisit
2699/2802/2944/3095/3258/3323/3407/3570 tetap eksperimental. Layout player-info
+0x10A8 / ID +0xE8 diperiksa terhadap pemain lokal serta tiap entry; pemeriksaan
ini bukan bukti nama/identitas jaringan. Label ID bukan nama asli.

Nama asli dan noclip belum memiliki backend; kontrol tetap disabled.
Tidak ada perubahan posisi/collision, bypass proteksi server/anti-cheat, atau
janji work all server. Library native harus berjalan dalam konteks script game
sesuai API; DLL ini masih menggunakan pembacaan memori dan hook DX11.

DIAGNOSTIK
Loader: klik kanan LIVE DEBUG lalu Copy debug.
DLL: Copy debug di menu atau %TEMP%/FiveMInternal-<PID>.log.
Jika crash lagi, sertakan log DLL dan readable report ID dari detail crash FiveM.
Loader menyimpan %TEMP%/FiveMInternal-loader-<PID>.log sebelum membuat jendela.
INJECTED berarti frame menu dikonfirmasi; itu belum membuktikan ESP valid.
DLL tertanam dalam EXE, diekstrak ke direktori berdasarkan hash di %TEMP%/FiveMInternal.
Tutup game sebelum mengganti versi; restart setelah timeout. Hook/worker tetap
resident hingga game ditutup. Menyembunyikan menu tidak mengeluarkan DLL.

UJI TERPISAH
RunSelfTest.cmd membuka DX11TestHost dan loader --test-host. Klik Inject, fokus
host, tekan C. Tidak ada data GTA. Uji Windows ini belum dijalankan di cloud.

LISENSI
ImGui v1.91.9b, MinHook v1.3.4, MinGW/GCC runtime statis. Lisensi dalam ZIP.
Binary unsigned.
