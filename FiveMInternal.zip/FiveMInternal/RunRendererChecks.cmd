@echo off
cd /d "%~dp0"
DX11StateChecks.exe
set "renderer_result=%errorlevel%"
echo.
echo This tests DirectX state isolation using WARP. It does not run FiveM.
pause
exit /b %renderer_result%
