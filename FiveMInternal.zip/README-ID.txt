FiveM Internal 2.0 — EKSPERIMENTAL, FITUR BELUM LENGKAP

Jalankan FiveMInternalLoader.exe di Windows x64. DLL sudah tertanam dalam EXE
serta diekstrak ke %TEMP%/FiveMInternal/<hash-build>/FiveMInternal.dll.
Tutup FiveM sebelum mengganti versi. Jangan jalankan dua loader sekaligus.

1. Masuk ke sesi FiveM, gunakan Windowed/Borderless.
2. Buka EXE, klik Inject. Jendela hitam/ungu menampilkan tahap dan loading.
3. Kembali ke FiveM. Loader menunggu sampai 30 detik untuk konfirmasi frame.
4. Tekan C untuk membuka/menutup menu; Tab/Space untuk navigasi keyboard.
5. Enable ESP dan pilih Skeleton/Box/ID labels. Semua checkbox awalnya OFF.
   Aktifkan Show local player untuk melihat diri sendiri (kamera third person).
   Show NPC mengikutkan NPC. Slider 10–1000 m memfilter entity yang sudah
   di-stream oleh game; tidak memuat pemain di luar jangkauan streaming.
6. F6 = master ESP ON/OFF; F7 = rescan. Semua fitur membutuhkan data valid.

STATUS FITUR
- Loader GUI, Inject, progress, debug, menu C: diimplementasikan.
- Skeleton, Box, ID/jarak, filter NPC/local dan slider: diimplementasikan.
- Nama pemain asli dan noclip BELUM DIIMPLEMENTASIKAN. Kontrolnya disabled.
  ID bukan nama pemain. Tidak ada perubahan posisi, collision, atau physics.
- Delapan profil pool: 2699, 2802, 2944, 3095, 3258, 3323, 3407, 3570.
  Semua profil berasal dari sumber publik dan belum diuji live di sini.
- Build lain, termasuk 3751: fallback signature world/viewport LOCAL ONLY.
  Tidak ada profil pool tervalidasi untuk 3751. Jika signature/data tidak cocok,
  tidak ada ESP yang digambar. Deteksi proses bukan jaminan kompatibilitas.
- Semua binary telah di-cross-compile, bukan dijalankan pada Windows/FiveM.

DIAGNOSTIK
Klik kanan area LIVE DEBUG di loader, pilih Copy debug.
Jika tidak ada jendela sama sekali, cek %TEMP%/FiveMInternal-loader-<PID>.log.
Debug DLL: %TEMP%/FiveMInternal-<PID>.log atau Copy debug di menu.
INJECTED hanya muncul setelah Start sukses dan frame DX11 dikonfirmasi.
Ini belum membuktikan data ESP valid. Timeout tidak otomatis mengulang inject;
restart FiveM sebelum mencoba lagi. Jangan menonaktifkan proteksi untuk retry.
Mouse game mungkin tetap terkunci; gunakan Tab/Space pada menu.

UJI TERPISAH
RunSelfTest.cmd membuka DX11TestHost dan loader dalam mode --test-host.
Klik Inject, fokus jendela DX11TestHost, tekan C. Tidak ada data GTA di host ini.
Uji resize/minimize/restore dan debug. Uji Windows ini belum dijalankan di cloud.

LISENSI
ImGui v1.91.9b dan MinHook v1.3.4, runtime MinGW/GCC statis.
Lisensi disertakan dalam paket ZIP. Binary unsigned.
