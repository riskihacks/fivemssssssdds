FiveM Internal 1.0 - EKSPERIMENTAL

Paket ini berisi loader EXE, DLL menu DirectX 11, dan host uji terpisah.
Belum diuji langsung pada Windows/FiveM build 3751. Berhasil load DLL atau
menampilkan menu tidak membuktikan pembacaan skeleton sudah cocok.

CARA MENCOBA DI FIVEM
1. Extract ZIP ke folder biasa di Windows. Jangan jalankan langsung dari ZIP.
2. Tutup monitor eksternal versi lama.
3. Jalankan FiveM build 3751 dan masuk game, gunakan Windowed/Borderless.
4. Jalankan FiveMInternalLoader.exe. FiveMInternal.dll harus ada di sebelahnya.
5. Baca hasil loader. Kembali ke game setelah inisialisasi berhasil.
6. Insert membuka/menutup menu. F6 mengaktifkan/mematikan local skeleton.
   F7 meminta scan ulang. Skeleton default OFF. Tab/Space bisa dipakai pada menu.
7. Untuk error, tekan Copy debug di menu, atau buka:
   %TEMP%\FiveMInternal-<PID>.log

MENU DAN DATA
- Menu memakai ImGui di frame DX11 game, bukan jendela overlay eksternal.
- Pembaca skeleton tetap pembaca memori, bukan pemanggil native FiveM/Lua.
- Hanya local player, sembilan titik dan delapan garis. Label LOCAL PLAYER;
  nama asli dan skeleton pemain lain belum diimplementasikan.
- Signature world/viewport dicari otomatis pada region executable yang terbaca.
- Tidak ada garis jika signature hilang/ambigu, data tulang tidak masuk akal,
  atau data lebih lama dari satu detik. Tidak menggambar skeleton contoh.
- Region guard/noaccess dan read yang gagal dilewati dan dicatat. Tidak ada
  perubahan proteksi memori untuk membaca data. ERROR_PARTIAL_COPY masih mungkin.
- Mouse menu bergantung pada input game. Gunakan F6/F7 atau navigasi keyboard
  jika game mengunci cursor. Menu belum memanggil DISABLE_CONTROL_ACTION.

PENTING SAAT MENGGANTI VERSI
OFF menghentikan pembacaan skeleton. Insert hanya menyembunyikan menu.
DLL/hook tetap dimuat sampai game ditutup. Tutup game sebelum mengganti DLL.
Tidak ada fitur unload saat runtime karena callback game dapat masih berjalan.
Loader menolak beberapa target sekaligus dan build selain 3751.
Akses proses yang ditolak tetap dilaporkan sebagai kegagalan, tanpa bypass.
Jika loader timeout, restart game sebelum mencoba lagi.

UJI MENU TERPISAH
RunSelfTest.cmd membuka DX11TestHost.exe dan menjalankan loader --test-host.
Cek menu, Insert, Copy debug, dan perubahan ukuran jendela. Host uji tidak punya
data GTA; skeleton tidak diharapkan muncul. Ini menguji pemuatan/menu saja.
Tes Windows ini belum dijalankan di cloud Linux. Jangan menyebutnya sudah lulus.

KETERGANTUNGAN
DLL dan EXE x64 ditautkan statis dengan runtime C++/MinHook, memakai DLL sistem
Windows/D3D11. ImGui v1.91.9b dan MinHook v1.3.4; lisensi disertakan.
Binary belum ditandatangani.
