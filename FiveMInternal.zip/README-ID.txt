FiveM Internal 2.2 — EKSPERIMENTAL

PERUBAHAN
- Memperbaiki kasus log pengguna: replay matches=31. Sampai 64 kecocokan
  diperiksa secara struktural, target/pool duplikat digabung. Hanya satu pool
  tervalidasi boleh dipakai; beberapa pool berbeda tetap ditolak.
- Heartbeat sampel setiap 5 detik mencatat validitas, pool, jumlah pemain,
  error baca dan umur frame render untuk membantu diagnosis penghentian.
- Scan replay/ped pool untuk build tanpa profil, termasuk percobaan build 3751.
  Diterima hanya jika pointer, kapasitas, isi pool dan pemain lokal tervalidasi.
  Mendukung bentuk objek langsung/pointer slot; bentuk ambigu ditolak.
- Pool dicoba lagi setiap 2 detik jika signature ditemukan sebelum spawn siap.
- Box memakai tinggi tubuh 1,96 m dan rasio lebar tetap, tidak mengikuti tangan.
  Ukuran layar masih berubah secara wajar saat jarak/kamera berubah.
- Cache tulang tervalidasi dipertahankan maksimal 150 ms saat sampel gagal,
  hanya untuk identitas sama dan perubahan posisi <=0,5 m. Tidak menahan pose
  saat berpindah sesi, teleport jauh, atau entity sudah tidak ada di pool.
- Box/ID bisa digambar walau sampel tulang gagal; skeleton tetap butuh tulang.
- Kamera dibaca saat render; target DirectX/UAV dan konteks ImGui dipulihkan.
- Debug menampilkan Other players, NPC, invalid reads/bones dan retained poses.

CARA MENCOBA
1. Tutup FiveM sepenuhnya. Unduh EXE baru dan jalankan sesi FiveM kembali.
2. Buka FiveMInternalLoader.exe, klik Inject lalu kembali ke FiveM.
3. Tekan C. Aktifkan Enable ESP serta Skeleton/Box. Semua opsi awalnya OFF.
4. Show local player hanya untuk diri sendiri; biarkan OFF saat menguji pemain
   lain. Show NPC untuk NPC. Slider 10–1000 m memfilter entity yang sudah di-stream.
5. F6 master ESP ON/OFF, F7 scan ulang. Tab/Space untuk navigasi keyboard.
6. Uji dekat pemain lain. Debug Other players harus >0 untuk memastikan pool
   berisi kandidat pemain lain. Projected entities menunjukkan hasil proyeksi.

STATUS DAN BATAS
Pengguna melaporkan ESP versi 2.0 sempat tampil lalu crash dan dump 2.1 juga menunjukkan terminasi. Log yang diberikan
hanya berakhir dengan "Early-exit trap", dengan execute fault pada GTAProcess+0x1D98. Lokasi ini cocok dengan klasifikasi
Early-exit trap di source FiveM, tetapi belum mengungkap pemicunya.
Perbaikan 2.2 belum dijalankan pada Windows/FiveM di cloud; crash belum terbukti
terselesaikan. Pengujian logika dan PE tidak membuktikan stabilitas game.

Pencarian pool otomatis tidak menjamin kecocokan semua build/server. Jika replay
atau layout player-info tidak valid, debug menjelaskan kegagalan. Profil eksplisit
2699/2802/2944/3095/3258/3323/3407/3570 tetap eksperimental. Layout player-info
+0x10A8 / ID +0xE8 diperiksa terhadap pemain lokal serta tiap entry; pemeriksaan
ini bukan bukti nama/identitas jaringan. Label ID bukan nama asli.

Nama asli dan noclip belum memiliki backend; kontrol tetap disabled.
Tidak ada perubahan posisi/collision, bypass proteksi server/anti-cheat, atau
janji work all server. Library native harus berjalan dalam konteks script game
sesuai API; DLL ini masih menggunakan pembacaan memori dan hook DX11.

DIAGNOSTIK
Loader: klik kanan LIVE DEBUG lalu Copy debug.
DLL: Copy debug di menu atau %TEMP%/FiveMInternal-<PID>.log.
Jika crash lagi, sertakan log DLL dan readable report ID dari detail crash FiveM.
Loader menyimpan %TEMP%/FiveMInternal-loader-<PID>.log sebelum membuat jendela.
INJECTED berarti frame menu dikonfirmasi; itu belum membuktikan ESP valid.
DLL tertanam dalam EXE, diekstrak ke direktori berdasarkan hash di %TEMP%/FiveMInternal.
Tutup game sebelum mengganti versi; restart setelah timeout. Hook/worker tetap
resident hingga game ditutup. Menyembunyikan menu tidak mengeluarkan DLL.

UJI TERPISAH
RunSelfTest.cmd membuka DX11TestHost dan loader --test-host. Klik Inject, fokus
host, tekan C. Tidak ada data GTA. Uji Windows ini belum dijalankan di cloud.

LISENSI
ImGui v1.91.9b, MinHook v1.3.4, MinGW/GCC runtime statis. Lisensi dalam ZIP.
Binary unsigned.
